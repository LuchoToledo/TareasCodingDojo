import logo from './logo.svg';
import './App.css';
import QueryPage from './components/pages/QueryPage.component';
import ErrorPage from './components/pages/ErrorPage.compect';

function App() {
  return (
    <div className="App">
     <QueryPage />
    </div>
  );
}

export default App;
