import obi_wan from '../../obi_wan.gif';

export default function ErrorPage(props) {
    return (
        <div>
            <img src={obi_wan} alt="" />
            <h2>Estos no son los droides que está buscando</h2>
        </div>
    )
}